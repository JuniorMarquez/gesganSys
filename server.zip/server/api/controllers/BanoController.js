/**
 * BanoController
 *
 * @description :: Server-side logic for managing banoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

