/**
 * TipoMedicamentoController
 *
 * @description :: Server-side logic for managing tipomedicamentoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

