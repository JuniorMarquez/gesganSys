/**
 * AlimentoController
 *
 * @description :: Server-side logic for managing alimentoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

