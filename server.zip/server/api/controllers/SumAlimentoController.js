/**
 * SumAlimentoController
 *
 * @description :: Server-side logic for managing sumalimentoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

