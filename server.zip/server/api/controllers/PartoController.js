/**
 * PartoController
 *
 * @description :: Server-side logic for managing partoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

