/**
 * SumMedicamentoController
 *
 * @description :: Server-side logic for managing summedicamentoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

